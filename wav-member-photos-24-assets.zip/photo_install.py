#!/usr/bin/env python3
"""WAV ARCHIVE 15.5+ S01-S24 photo release.
One-time safe HTML face image replacement plus shared avatar registry.
Assets are stored locally (no external image hotlinks). Rollback restores original
per-member image src without discarding unrelated post-installation HTML edits.
"""
from pathlib import Path
import os, re, json, gzip, shutil

ROOT=Path('.')
PREFIX=Path('assets/member-profiles')
IMAGES=PREFIX/'2026-10'
BACKUP=PREFIX/'original-member-image-srcs.json.gz'
SCRIPT=PREFIX/'member-photo-sync.js'
PAGES=[Path('index.html'),Path('wav-labs/index.html'),Path('wav-plus-lab/index.html'),
       Path('objekt-collection/index.html'),Path('bias-curator/index.html')]
ID_PATTERN=re.compile(r'S(?:0[1-9]|1\d|2[0-4])')
ARTICLE_PATTERN=re.compile(r'<article\b[^>]*\bdata-member=["\'](S\d{2})["\'][^>]*>', re.I|re.S)
IMG_PATTERN=re.compile(r'<img\b[^>]*>',re.I|re.S)
SRC_PATTERN=re.compile(r'\bsrc\s*=\s*(["\'])(.*?)\1',re.I|re.S)
CLASS_PATTERN=re.compile(r'\bclass\s*=\s*(["\'])(.*?)\1',re.I|re.S)
SCRIPT_ID='wav-member-photo-registry-2026-10'
SCRIPT_TAG_TEMPLATE='<script id="'+SCRIPT_ID+'" defer src="{src}"></script>'

def check_payload():
    if not SCRIPT.is_file(): raise SystemExit('Missing member-photo-sync.js')
    if not Path('index.html').exists(): raise SystemExit('Missing root index.html; did not modify files')
    for idx in range(1,25):
        sid=f'S{idx:02d}'
        for suffix in ('', '-thumb'):
            path=IMAGES/f'{sid}{suffix}.webp'
            if not path.is_file() or path.stat().st_size<1000: raise SystemExit(f'Invalid or missing {path}')

def replace_src(imgtag, new_value):
    if SRC_PATTERN.search(imgtag):
        return SRC_PATTERN.sub(lambda m: 'src='+m.group(1)+new_value+m.group(1),imgtag,count=1)
    return imgtag[:-1]+f' src="{new_value}">'

def modify_home(html, rollback=False, sources=None):
    """Only the 24 member card front images. Never touch back character art."""
    changes=[]; old={}
    for match in ARTICLE_PATTERN.finditer(html):
        sid=match.group(1).upper()
        if not ID_PATTERN.fullmatch(sid): continue
        end=html.find('</article>',match.end())
        if end<0: continue
        chunk=html[match.end():end]
        for imgmatch in IMG_PATTERN.finditer(chunk):
            tag=imgmatch.group(0)
            cl=CLASS_PATTERN.search(tag)
            if not cl or 'member-photo' not in cl.group(2).split(): continue
            src=SRC_PATTERN.search(tag)
            if not src: continue
            prior=src.group(2)
            target=str(IMAGES/f'{sid}.webp').replace('\\','/')
            if rollback:
                # Do not clobber a manually changed picture.
                if prior!=target or sid not in (sources or {}): continue
                target=sources[sid]
            else:
                if prior==target: continue
                old[sid]=prior
            absolute_start=match.end()+imgmatch.start()
            absolute_end=match.end()+imgmatch.end()
            changes.append((absolute_start,absolute_end,replace_src(tag,target)))
            break
    for start,end,tag in reversed(changes):
        html=html[:start]+tag+html[end:]
    return html,old,len(changes)

def update_script_tag(html,depth,rollback=False):
    pat=re.compile(r'\s*<script\s+id=["\']'+SCRIPT_ID+r'["\'][^>]*>\s*</script>\s*',re.I|re.S)
    html=pat.sub('',html)
    if rollback:return html
    target='../'*depth+str(SCRIPT)
    tag=SCRIPT_TAG_TEMPLATE.format(src=target+'?v=20261025')
    closing=list(re.finditer(r'</body\s*>',html,re.I))
    if not closing: return html
    pos=closing[-1].start()
    return html[:pos]+'\n'+tag+'\n'+html[pos:]

def apply():
    check_payload()
    if BACKUP.exists():
        old=json.loads(gzip.decompress(BACKUP.read_bytes()).decode('utf8'))
    else: old={}
    count=0
    modified=[]
    for p in PAGES:
        if not p.is_file():continue
        html=p.read_text(encoding='utf8')
        if p==PAGES[0]:
            html,sources,updated=modify_home(html)
            old.update(sources);count+=updated
        html2=update_script_tag(html,len(p.parts)-1)
        if html2!=p.read_text(encoding='utf8'):
            p.write_text(html2,encoding='utf8')
            modified.append(str(p))
    if old:
        BACKUP.write_bytes(gzip.compress(json.dumps(old,ensure_ascii=False).encode('utf8'),compresslevel=6))
    if count not in (0,24):
        # Files remain usable thanks to global registry, but log unexpected card counts.
        print(f'WARNING: replaced {count}/24 inline hero images, registry will handle the rest')
    print('OK: member hero src replaced:',count,'backups:',len(old),'HTML:',modified)

def rollback():
    old={}
    if BACKUP.is_file():old=json.loads(gzip.decompress(BACKUP.read_bytes()).decode('utf8'))
    for p in PAGES:
        if not p.is_file(): continue
        html=p.read_text(encoding='utf8')
        if p==PAGES[0]:html,_,restored=modify_home(html,rollback=True,sources=old)
        else:restored=0
        html=update_script_tag(html,len(p.parts)-1,rollback=True)
        p.write_text(html,encoding='utf8')
        print(f'{p} rollback restored images={restored}')
    # Never delete original image source backups until recovery succeeded.
    if BACKUP.exists():BACKUP.unlink()
    if PREFIX.exists():shutil.rmtree(PREFIX)
    print('OK: removed photos, runtime and backup after restoration')

if __name__=='__main__':
    mode=os.getenv('WAV_PHOTO_ACTION','apply').strip().lower()
    if mode=='apply':apply()
    elif mode=='rollback':rollback()
    else:raise SystemExit('Invalid action (apply/rollback)')
